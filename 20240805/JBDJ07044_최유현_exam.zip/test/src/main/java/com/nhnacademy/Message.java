package com.nhnacademy;

import java.time.LocalTime;

public abstract class Message {
    LocalTime now;



    public LocalTime getNow(){
        return now;
    }


}
