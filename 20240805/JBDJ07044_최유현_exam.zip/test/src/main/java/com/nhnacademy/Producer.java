package com.nhnacademy;

public interface Producer {
    
}
