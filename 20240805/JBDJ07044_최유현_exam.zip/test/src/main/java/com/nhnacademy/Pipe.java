package com.nhnacademy;

public class Pipe {
    
}
