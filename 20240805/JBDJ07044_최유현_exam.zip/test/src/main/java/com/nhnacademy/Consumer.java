package com.nhnacademy;

public interface Consumer {
    
}
