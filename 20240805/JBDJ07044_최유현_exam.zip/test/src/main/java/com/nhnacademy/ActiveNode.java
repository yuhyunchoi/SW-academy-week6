package com.nhnacademy;

public class ActiveNode {
    
}
